# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['labtools', 'labtools.adtools', 'labtools.predictors']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.7.1,<4.0.0',
 'more-itertools>=9.0.0,<10.0.0',
 'numpy>=1.24.2,<2.0.0',
 'pandas>=1.5.3,<2.0.0',
 'seaborn>=0.12.2,<0.13.0',
 'sklearn>=0.0.post1,<0.1']

setup_kwargs = {
    'name': 'labtools',
    'version': '0.0.3',
    'description': 'Staller lab tools for sequence design and analysis',
    'long_description': '# labtools\n\nTools useful in Staller Lab for sequence design and analysis. Someone should rename me to something better.\n\n## Installation\n\n```bash \npip install https://github.com/massivejords/tools/blob/main/dist/labtools-0.0.1-py3-none-any.whl?raw=true\n```\n\n## Usage\n\n[View the in progress documentation webpage.](https://massivejords.github.io/tools/docs/_build/html/index.html)\n\n[See examples](https://massivejords.github.io/tools/docs/_build/html/example.html)\n\n[Look at functions and classes (with examples)](https://massivejords.github.io/tools/docs/_build/html/autoapi/index.html)\n\n```python\nimport labtools\nfrom labtools.adtools import sort\n```\n\n## License\n\n`labtools` was created by Jordan Stefani. It is licensed under the terms of the MIT license.\n\n\n## Credits\n\n`labtools` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'Jordan Stefani',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
