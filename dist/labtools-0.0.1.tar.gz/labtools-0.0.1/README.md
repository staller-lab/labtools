# labtools

tools for sequence design and analysis

[View the in progress documentation.](https://massivejords.github.io/tools/docs/_build/html/index.html)

## Installation

```bash 
pip install https://github.com/massivejords/tools/blob/main/dist/labtools-0.0.1-py3-none-any.whl?raw=true
```

## Usage

- TODO

## License

`labtools` was created by Jordan Stefani. It is licensed under the terms of the MIT license.





## Credits

`labtools` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
