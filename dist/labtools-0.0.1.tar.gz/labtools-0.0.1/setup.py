# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['labtools', 'labtools.adtools']

package_data = \
{'': ['*']}

install_requires = \
['more-itertools>=9.0.0,<10.0.0',
 'numpy>=1.24.2,<2.0.0',
 'pandas>=1.5.3,<2.0.0',
 'seaborn>=0.12.2,<0.13.0']

setup_kwargs = {
    'name': 'labtools',
    'version': '0.0.1',
    'description': 'Staller lab tools for sequence design and analysis',
    'long_description': '# labtools\n\ntools for sequence design and analysis\n\n[View the in progress documentation.](https://massivejords.github.io/tools/docs/_build/html/index.html)\n\n## Installation\n\n```bash \npip install https://github.com/massivejords/tools/blob/main/dist/labtools-0.0.1-py3-none-any.whl?raw=true\n```\n\n## Usage\n\n- TODO\n\n## License\n\n`labtools` was created by Jordan Stefani. It is licensed under the terms of the MIT license.\n\n\n\n\n\n## Credits\n\n`labtools` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'Jordan Stefani',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
